const News = () => {
    return (
        <>
            <p>
            News
            </p>
        </>
    )
}

export default News;