const Footer = () => {
    return (
        <>
            <p>
                Account
            </p>
        </>
    )
}

export default Footer;