import TopSection from './topSection';
import Table from './table';

const AssociatedWallets = () => {
  return (
    <div className="mt-2 ">
      <TopSection />
      <Table />
    </div>
  );
};

export default AssociatedWallets;
