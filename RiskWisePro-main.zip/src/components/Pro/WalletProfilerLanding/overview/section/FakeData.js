export const Daily = [
  {
    name: "Mon",
    value: 3203
  },
  {
    name: "Tue",
    value: 4000
  },
  {
    name: "Wed",
    value: 5203
  },
  {
    name: "Thu",
    value: 6203
  },
  {
    name: "Fri",
    value: 7203
  },
  {
    name: "Sat",
    value: 5203
  },
  {
    name: "Sun",
    value: 6203
  }
];

export const Hourly = [
  { value: 6203 },
  { value: 5485 },
  { value: 6958 },
  { value: 7854 },
  { value: 2548 },
  { value: 9468 },
  { value: 1587 },
  { value: 6845 },
  { value: 5987 },
  { value: 5385 },
  { value: 9485 },
  { value: 7865 },
  { value: 4859 },
  { value: 6856 },
  { value: 5896 },
  { value: 4545 },
  { value: 4658 },
  { value: 7456 },
  { value: 8245 },
  { value: 4285 },
  { value: 5624 },
  { value: 4524 },
  { value: 8524 },
  { value: 4732 }
];

export const AllTime = [
  {
    name: "11/12/2023",
    value: 3203
  },
  {
    name: "11/13/2023",
    value: 4000
  },
  {
    name: "11/14/2023",
    value: 5203
  },
  {
    name: "11/15/2023",
    value: 6203
  },
  {
    name: "11/16/2023",
    value: 7203
  },
  {
    name: "11/17/2023",
    value: 5203
  },
  {
    name: "11/18/2023",
    value: 6203
  },
  {
    name: "11/19/2023",
    value: 3203
  },
  {
    name: "11/20/2023",
    value: 4000
  },
  {
    name: "11/21/2023",
    value: 5203
  },
  {
    name: "11/22/2023",
    value: 6203
  },
  {
    name: "11/23/2023",
    value: 7203
  },
  {
    name: "11/24/2023",
    value: 5203
  },
  {
    name: "11/25/2023",
    value: 6203
  },
  {
    name: "11/26/2023",
    value: 3203
  },
  {
    name: "11/27/2023",
    value: 4000
  },
  {
    name: "11/28/2023",
    value: 5203
  },
  {
    name: "11/29/2023",
    value: 6203
  },
  {
    name: "11/30/2023",
    value: 7203
  },
  {
    name: "12/1/2023",
    value: 5203
  },
  {
    name: "12/2/2023",
    value: 6203
  }
];