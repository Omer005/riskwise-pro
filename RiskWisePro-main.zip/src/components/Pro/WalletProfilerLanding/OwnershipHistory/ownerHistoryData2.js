import { ADA, Ape, Ape2, Ape3, Ape4 } from "../../../../common/IMG/Images";
export const ownerHistoryData2 = {
  itemValue: [
    {
      id: 0,
      collection: {
        image: ADA,
        value: "ADA Handle"
      },
      price: 1200,
      percent: 30,
    },
    {
      id: 1,
      collection: {
        image: Ape2,
        value: "Ape Society"
      },
      price: 100,
      percent: 20,
    },
    {
      id: 2,
      collection: {
        image: Ape,
        value: "Ape Soceity"
      },
      price: 900,
      percent: 10,
    },
    {
      id: 3,
      collection: {
        image: Ape3,
        value: "Ape Soceity"
      },
      price: 300,
      percent: 100,
    },
    {
      id: 4,
      collection: {
        image: Ape4,
        value: "Ape Soceity"
      },
      price: 40,
      percent: 30,
    },
    {
      id: 5,
      collection: {
        image: ADA,
        value: "ADA Handle"
      },
      price: 1200,
      percent: 30,
    },
    {
      id: 6,
      collection: {
        image: Ape2,
        value: "Ape Society"
      },
      price: 100,
      percent: 20,
    },
    {
      id: 7,
      collection: {
        image: Ape,
        value: "Ape Soceity"
      },
      price: 900,
      percent: 10,
    },
    {
      id: 8,
      collection: {
        image: Ape3,
        value: "Ape Soceity"
      },
      price: 300,
      percent: 100,
    },
    {
      id: 9,
      collection: {
        image: Ape4,
        value: "Ape Soceity"
      },
      price: 40,
      percent: 30,
    },
  ],
  maxIncome: 100,
};
