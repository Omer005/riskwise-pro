const HeaderButton = () => {
  return (
    <>
      <div id="connetWallet" className="absolute right-4 top-6">
        <button
          type=""
          className="bg-gradient-to-r from-yellow-200 to-yellow-400 text-black py-[5px] px-7 rounded-xl"
        >
          Connet Wallet
        </button>
      </div>
    </>
  );
};

export default HeaderButton;
