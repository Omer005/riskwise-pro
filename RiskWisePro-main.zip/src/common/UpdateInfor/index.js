const UpdateInfor ={
    DailyVolume: "290,696 €",
    PooledEUR: "1,445,398€",
    PooledLENFI: "662,828 LENFI",
    Holoders: "8,754",
    TotalTx:"117,708",
    MarketCap:"31,209,340 €",
    DilutedMarketCap:"64,328,742 €",
    CirculatingSupply:"14.31M (48.5%",
    TotalSupply:"29.50M",
    ProtocolTVL:"6.06M €",
    MarketCapTVL:"5.15",
    PooledPercent:"4.63 %",
    OneEUR:"    0.46 LENFI"
}
export default UpdateInfor 