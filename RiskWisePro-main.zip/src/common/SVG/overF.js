import * as IMG from "../../common/IMG/Images"

const OverF = () => {
  return (
    <div className="flex w-8 h-8 justify-center items-center">
      <img
        src={IMG.logo5}
        height={30}
        width={30}
        className=""
        alt="logo" />
    </div>
  );
};
export default OverF;